package com.ztriplezero.c0742318_midterm_mad3125f2018;

import android.accounts.Account;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ElectricityBillActivity extends AppCompatActivity {

    ElectricityBill db;
    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private static final String PREFS_NAME = "LoginPrefs";
    private TextView textViewWelcome;
    private Button lgOutButton;
    EditText cid, cname, cemail, cunits;
    private RadioGroup radioGroupGender;
    TextView cdate;
    RadioButton rb;
    Button btnSumbitClicked;
   // private RadioButton male;
   // private RadioButton female;
   // private RadioButton others;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electricity_bill);
        radioGroupGender = findViewById(R.id.rgGender);

        cid = (EditText) findViewById(R.id.editText_customerID);
        cname = (EditText) findViewById(R.id.editText_customerName);
        cemail = (EditText) findViewById(R.id.editText_customerEmailId);
        //cgender = (RadioGroup)findViewById(R.id.GroupGender);
        cdate = (TextView) findViewById(R.id.textView_datePicker);
        cunits = (EditText) findViewById(R.id.editText_unitConsumed);
        //final int cgender2 = cgender.getCheckedRadioButtonId();


        mDisplayDate = (TextView) findViewById(R.id.textView_datePicker);
        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat mdformat = new SimpleDateFormat("yyyy / MM / dd ");
                String strDate = mdformat.format(calendar.getTime());
                display(strDate);


            }

            private void display(String num) {
                TextView textView = (TextView) findViewById(R.id.textView_datePicker);
                textView.setText(num);
            }
        });


        lgOutButton = (Button) findViewById(R.id.buttonLogout);
        textViewWelcome = (TextView) findViewById(R.id.textViewWelcome);
        Intent intent = getIntent();
        Account account = (Account) intent.getSerializableExtra("account");
        String userEmailid = getIntent().getStringExtra("username");
        textViewWelcome.setText(userEmailid);
        cemail.setText(userEmailid);


        lgOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.remove("logged");
                editor.commit();
                finish();
            }
        });

        btnSumbitClicked = (Button) findViewById(R.id.btnSubmit);
        btnSumbitClicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radiobuttonid = radioGroupGender.getCheckedRadioButtonId();
                radioGroupGender = (RadioGroup) findViewById(R.id.rgGender);
                String custid = cid.getText().toString();
                String custname = cname.getText().toString();
                String custemail = cemail.getText().toString();
                String custgender = rb.getText().toString();
                String custdate = cdate.getText().toString();
                String custunits = cunits.getText().toString();

                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(custemail).matches()) {
                    Toast.makeText(getApplicationContext(), "enter valid email", Toast.LENGTH_SHORT).show();

                    if (custid.equals("") || custname.equals("") || custemail.equals("") || custgender.equals("") || custdate.equals("") || custunits.equals("")) {
                        Toast.makeText(getApplicationContext(), "All Fields are Reqired", Toast.LENGTH_SHORT).show();
                    }


                } else {

                        Boolean insert = db.insert(custid, custname, custemail, custgender, custdate, custunits);
                        if (insert == true) {
                            Toast.makeText(getApplicationContext(), "Record Inserted", Toast.LENGTH_SHORT).show();
                        }
                     else {
                        Toast.makeText(getApplicationContext(), "Something went wrong", Toast.LENGTH_SHORT).show();
                    }


                }
            }


        });

    }


}
