package com.ztriplezero.c0742318_midterm_mad3125f2018;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ElectricityBill extends SQLiteOpenHelper {

    //DATABASE NAME
    public static final String DATABASE_NAME = "customer.db";

    //DATABASE VERSION
    public static final int DATABASE_VERSION = 1;

    //TABLE NAME
    public static final String TABLE_CUSTOMER = "customer";

    //TABLE USERS COLUMNS
    //ID COLUMN @primaryKey
    public static final String KEY_AUTO = "id";
    public static final String KEY_CID = "customerid";
    public static final String KEY_NAMAE = "customername";
    public static final String KEY_CEMAIL = "customeremail";
    public static final String KEY_GENDER= "customergender";
    public static final String KEY_DATE = "billdate";
    public static final String KEY_UNITS = "units";
    public ElectricityBill(Context context) {
        super(context, "customer.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase datab) {
        datab.execSQL("create table customer (id integer primary key autoincrement ,customerid text,customername text,customeremail text,customergender text,billdate text,units text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists customer");

    }
    public  boolean insert (String customerid , String customername , String customeremail , String customergender , String billdate , String units)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("customerid",customerid);
        contentValues.put("customername",customername);
        contentValues.put("customeremail",customeremail);
        contentValues.put("customergender",customergender);
        contentValues.put("billdate",billdate);
        contentValues.put("units",units);
        long insert = db.insert("customer", null,contentValues);
        if (insert == -1)

        {
            return  false;
        }
        else
        {
            return true;
        }

    }





}
