package com.ztriplezero.c0742318_midterm_mad3125f2018;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

     RegisterDataBaseHelper db;
     EditText emailContent,pwdContent,cpwdContent;
     Button btnRegisterClicked;
     Button btnCancle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new RegisterDataBaseHelper(this);

        emailContent = (EditText) findViewById(R.id.editText_regEmail);
        pwdContent = (EditText)findViewById(R.id.editText_regPass);
        cpwdContent = (EditText)findViewById(R.id.editText_cpwd);
        btnRegisterClicked =(Button)findViewById(R.id.buttonRegister);

        btnRegisterClicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = emailContent.getText().toString();
                String pwd = pwdContent.getText().toString();
                String cpwd = cpwdContent.getText().toString();

                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(getApplicationContext(),"enter valid email",Toast.LENGTH_SHORT).show();

                if (email.equals("") || pwd.equals("") || cpwd.equals(""))
                {
                    Toast.makeText(getApplicationContext(),"All Fields are Reqired",Toast.LENGTH_SHORT).show();
                }


                if (!pwd.equals(cpwd))
                {
                    Toast.makeText(getApplicationContext(),"Password Doesn't match",Toast.LENGTH_SHORT).show();

                }}


                else
                {
                    if(pwd.equals(cpwd))
                    {
                        Boolean chkemail = db.chkemail(email);
                        if (chkemail==true)
                        {
                            Boolean insert = db.insert(email,pwd);
                            if (insert==true)
                            {
                                Toast.makeText(getApplicationContext(),"Regiteration Success",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Email already exists",Toast.LENGTH_SHORT).show();
                        }
                    }

                }

            }
        });

        btnCancle = (Button)findViewById(R.id.btnCancle);

        btnCancle.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          CancleIntent();
                                      }
                                  }
        );
    }

    public  void CancleIntent()
    {
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
    }
    }

