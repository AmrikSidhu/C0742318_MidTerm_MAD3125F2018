package com.ztriplezero.c0742318_midterm_mad3125f2018;

public class User {
    public String id;
    public String email;
    public String password;

    public User(String id, String email, String password) {
        this.id = id;
        this.email = email;
        this.password = password;
    }

}