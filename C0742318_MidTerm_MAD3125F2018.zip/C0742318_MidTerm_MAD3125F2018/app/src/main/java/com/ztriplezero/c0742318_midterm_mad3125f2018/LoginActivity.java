 package com.ztriplezero.c0742318_midterm_mad3125f2018;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

 public class LoginActivity extends AppCompatActivity {
     public static final String PREFS_NAME = "LoginPrefs";
     RegisterDataBaseHelper db;
     RegisterDataBaseHelper sqliteHelper;
     private  Button login;
     private EditText editemail,editpassword;
     final Context context = this;


    private Button btnReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        if (settings.getString("logged", "").toString().equals("logged")) {
            Intent intent = new Intent(LoginActivity.this, ElectricityBillActivity.class);
            startActivity(intent);
        }

        sqliteHelper = new RegisterDataBaseHelper(this);

        editemail = (EditText)findViewById(R.id.logEmail);
        editpassword =(EditText)findViewById(R.id.logPass);
        login = (Button)findViewById(R.id.buttonLogin);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String uemail = editemail.getText().toString();
                String upass = editpassword.getText().toString();

                if (validate()) {

                    //Get values from EditText fields
                   // String Email = editemail.getText().toString();
                   // String Password = editpassword.getText().toString();

                    //Authenticate user
                    User currentUser = sqliteHelper.Authenticate(new User(null, uemail, upass));

                    //Check Authentication is successful or not
                    if (currentUser != null) {

                        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString("logged", "logged");
                        editor.commit();

                        Toast.makeText(getApplicationContext(),"login Success",Toast.LENGTH_SHORT).show();
                        loginSuccess();


                        //User Logged in Successfully Launch You home screen activity
                       /* Intent intent=new Intent(LoginActivity.this,HomeScreenActivity.class);
                        startActivity(intent);
                        finish();*/
                    } else {
                        AlertDialog.Builder builder;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            builder = new AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert);
                        } else {
                            builder = new AlertDialog.Builder(context);
                        }
                        builder.setTitle("wrong user name or password")
                                .setMessage("please check all fields")
                                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {

                                    }

                                })
                                .show();/*
                               .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        // do nothing
                                    }
                                })
                               .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();*/



                        //User Logged in Failed
                       Toast.makeText(getApplicationContext(),"login Failed",Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });


        btnReg = (Button)findViewById(R.id.btnRegister);
        btnReg.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          RegIntent();
                                      }
                                  }
        );
    }

    public  void RegIntent()
    {
        Intent intent = new Intent(this,RegisterActivity.class);
        startActivity(intent);
    }
     public boolean validate() {
         boolean valid = false;

         //Get values from EditText fields
         String Email = editemail.getText().toString();
         String Password = editpassword.getText().toString();

         //Handling validation for Email field
         if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
             valid = false;
             Toast.makeText(getApplicationContext(),"enter valid email",Toast.LENGTH_SHORT).show();
         } else {
             valid = true;
             Toast.makeText(getApplicationContext(),"welcome",Toast.LENGTH_SHORT).show();
         }

         //Handling validation for Password field
         if (Email.isEmpty() || Password.isEmpty()) {
             valid = false;
             Toast.makeText(getApplicationContext(),"user name and password can not be Empty!",Toast.LENGTH_SHORT).show();
         }

         return valid;
     }

     public  void loginSuccess()
     {
         String value = editemail.getText().toString();
         //Intent intent = new Intent(this,ElectricityBillActivity.class);
         Intent intent = new Intent(LoginActivity.this,ElectricityBillActivity.class);
         intent.putExtra("username",value);

         startActivity(intent);
     }

}
